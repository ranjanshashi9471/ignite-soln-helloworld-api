const language = {
	english: "Hello world",
	hindi: "Namastey sansar",
	french: "Bonjour le monde",
};

export default language;
